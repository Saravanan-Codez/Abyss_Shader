#version 150 compatibility

in vec2 vTexCoord;

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform sampler2D shadowtex0; // Opaque shadow depth

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;

/* DRAWBUFFERS:0 */
layout(location = 0) out vec4 fragColor;

void main() {
    vec4 color = texture(colortex0, vTexCoord);
    float depth = texture(depthtex0, vTexCoord).r;

    // Do not calculate shadows for the sky
    if (depth < 1.0) {
        // 1. Convert Screen Space to Normalized Device Coordinates (NDC)
        vec4 ndcPos = vec4(vTexCoord.x * 2.0 - 1.0, vTexCoord.y * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
        
        // 2. Reconstruct View Space
        vec4 viewPos = gbufferProjectionInverse * ndcPos;
        viewPos /= viewPos.w;
        
        // 3. Reconstruct Player Space
        vec4 playerPos = gbufferModelViewInverse * viewPos;
        
        // 4. Transform to Shadow Space
        vec4 shadowSpace = shadowProjection * shadowModelView * playerPos;
        
        // 5. Convert Shadow NDC to Texture Coordinates [0, 1]
        vec3 shadowCoord = shadowSpace.xyz * 0.5 + 0.5;
        
        // 6. Basic Occlusion Test
        // Read the depth stored in the shadow map
        float sampledDepth = texture(shadowtex0, shadowCoord.xy).r;
        
        // Prevent shadow acne with a tiny bias
        float bias = 0.001; 
        
        // If the pixel is further from the sun than the shadow map recorded, it is in shadow!
        if (shadowCoord.z - bias > sampledDepth) {
            color.rgb *= 0.5; // Darken the pixel by 50%
        }
    }

    fragColor = color;
}
