#version 150 compatibility
#include "/shaders.settings"

in vec4 vColor;
in vec2 vTexCoord;
in vec2 vLightmapCoord;
in vec3 vNormal;

uniform sampler2D gtexture;
uniform sampler2D lightmap;

layout(location = 0) out vec4 colortex0;
layout(location = 1) out vec4 colortex1;
layout(location = 2) out vec4 colortex2;

void main() {
    // 1. Get Base Color
    vec4 albedo = texture(gtexture, vTexCoord) * vColor;
    if (albedo.a < 0.05) discard;
    
    // 2. Sample Lightmap
    vec4 light = texture(lightmap, vLightmapCoord);
    
    // 3. Combine: Albedo * Light
    vec3 finalColor = albedo.rgb * light.rgb;
    
    // 4. Gamma Correction
    finalColor = pow(finalColor, vec3(2.2));
    
    colortex0 = vec4(finalColor, albedo.a);
    colortex1 = vec4(normalize(vNormal) * 0.5 + 0.5, 1.0);
    colortex2 = vec4(vLightmapCoord, 0.0, 1.0);
}
