#version 150 compatibility

in vec2 vTexCoord;

uniform sampler2D colortex0;

#define BLOOM_ON

/* DRAWBUFFERS:0 */
layout(location = 0) out vec4 fragColor;

// ACES Tone Mapping Formula
vec3 ACESFilm(vec3 x) {
    float a = 2.51f;
    float b = 0.03f;
    float c = 2.43f;
    float d = 0.59f;
    float e = 0.14f;
    return clamp((x*(a*x+b))/(x*(c*x+d)+e), 0.0, 1.0);
}

void main() {
    vec4 color = texture(colortex0, vTexCoord);

    #ifdef BLOOM_ON
    // Fast offset downsampled bloom extraction
    vec2 offset = vec2(0.002, 0.002);
    vec4 bloom = texture(colortex0, vTexCoord + offset);
    bloom += texture(colortex0, vTexCoord - offset);
    bloom += texture(colortex0, vTexCoord + vec2(-offset.x, offset.y));
    bloom += texture(colortex0, vTexCoord + vec2(offset.x, -offset.y));
    
    // Add glow back to original color
    color.rgb += (bloom.rgb * 0.1); 
    #endif

    // ACES Tone Mapping
    color.rgb = ACESFilm(color.rgb);
    
    // Final Gamma Encoding for display
    color.rgb = pow(color.rgb, vec3(1.0 / 2.2));

    fragColor = vec4(color.rgb, 1.0);
}
